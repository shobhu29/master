package com.capgemini.capstore.exceptions;

public class MerchantNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MerchantNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
