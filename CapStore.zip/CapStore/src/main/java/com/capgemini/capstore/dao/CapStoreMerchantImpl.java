package com.capgemini.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Merchant;

@Repository
@Transactional
public class CapStoreMerchantImpl implements CapStoreMerchant {

	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public Merchant getDetailsofMerchant(String merchantMobileNumber) {
		Merchant merchant = new Merchant();
		merchant = entitymanager.find(Merchant.class,merchantMobileNumber );
		return merchant;
	}

	@Override
	public String save(Merchant merchant) {

		entitymanager.persist(merchant);
		return "Merchant Added Successfully";
	}

}
