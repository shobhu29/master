package com.capgemini.capstore.dao;

import com.capgemini.capstore.beans.Merchant;

public interface CapStoreMerchant {
	
	
	public Merchant getDetailsofMerchant(String merchantMobileNumber);
	
	public String save(Merchant merchant);
	
}

