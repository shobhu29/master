package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.CapStoreMerchant;
import com.capgemini.capstore.exceptions.MerchantAlreadyExistException;

public class MerchantValidateServiceImpl implements IMerchantValidateService {

	@Autowired
	CapStoreMerchant dao;


	@Override
	public String merchantValidation(Merchant merchant) throws MerchantAlreadyExistException {
		// TODO Auto-generated method stub
		
		if(dao.getDetailsofMerchant(merchant.getMerchantMobileNumber()) == null)
			return "Merchant Validated successfully";
		else
			throw new MerchantAlreadyExistException("Merchant Already Exists");
	}

}
