package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.exceptions.MerchantAlreadyExistException;

public interface IMerchantValidateService {

	public String merchantValidation(Merchant merchant) throws MerchantAlreadyExistException;

}
