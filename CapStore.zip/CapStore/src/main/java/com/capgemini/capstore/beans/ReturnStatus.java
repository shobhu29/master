package com.capgemini.capstore.beans;

public enum ReturnStatus {
	Applied, Approved, Rejected
}
