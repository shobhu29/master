package com.capgemini.capstore.beans;

public enum DeliveryStatus {
	Ordered, Shipped, OutForDelivery, Delivered
}
