package com.capgemini.capstore.main.service;

import java.io.IOException;

import com.capgemini.capstore.main.beans.Email;
import com.capgemini.capstore.main.beans.Role;

public interface CapStoreEmailService {

	public Email generateNewEmail(String receiverEmailId, Role receiverRole) throws IOException;

	public Email updateEmail(String receiverEmailId, Role receiverRole) throws IOException;

	public boolean verifyEmail(String receiverEmailId, Role receiverRole) throws IOException;
}
